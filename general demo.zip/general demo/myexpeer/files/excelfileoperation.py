import openpyxl
def readexcel(path,cell,row):
    # print('read excel called')
    wb=openpyxl.load_workbook(path)
    sheet=wb.active
    print(sheet[cell+row].value)
    wb.save(path)
def writeexcel(path,cell,row,content):
    #excel create
    # wb=openpyxl.Workbook()
    wb=openpyxl.load_workbook(path)
    sheet=wb.active
    sheet[cell+row]=content
    #close
    wb.save(path)