#module
#contain only--->defination functions,var,classes
modes=('r','r+','w','a')

def readtext(path,mode):
    file=open(path,'r')
    if(mode=='all'):
        return file.read()
    elif(mode=='line'):
        return file.readline()
    elif (mode=='lines'):
        return file.readlines()
    elif (isinstance(mode,int)):
        return  file.read(mode)
    else:
        return 'invalid mode'
    file.close()

def writetext(content,path):
    file=open(path,'w')
    file.write(content)
    file.close()

