# import os
# print(os.getcwd())
# if(os.getlogin()=='jboles'):
#     if(os.name=='nt'): #return commercial name nt--->windows
#         os.chdir('C:\\')
#         print(os.system('dir'))
#     else:
#         os.chdir('/home/jboles/')
#         print(os.system('ls -l'))

# import sys
# try:
#     1/0
# except:
#     print(sys.exc_info()[1])
# import socket
# s=socket.socket('127.0.0.1')
# email=input('enter email')
# import sys
# print(sys.argv)
# #reaualre
# import re
# #string validation
# #check straing is email or string contain email or string more than email
# email=input('enter email')
# #regulare expresssion--->([a-z A-Z 0-9])@
# regex=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
# #check straing is email
# print(re.fullmatch(regex,email))
# print(re.match(regex,email))#str must statrt by email
# print(re.search(regex,email))
# print(re.findall(regex,email))

# import myexpeer.files.simplefileoperation
#
# print(myexpeer.files.simplefileoperation.modes)
#
# from myexpeer.files.simplefileoperation import *
# print(modes)
#
# from myexpeer.files.excelfileoperation import *
# readexcel('asd.xlsx',1,1)
from myexpeer.files.excelfileoperation import *
writeexcel('asd.xlsx','A','1','hi')
writeexcel('asd.xlsx','B','2','fci')
readexcel('asd.xlsx','A','1')
readexcel('asd.xlsx','B','2')
